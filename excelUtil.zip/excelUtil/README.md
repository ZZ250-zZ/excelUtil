- 1.构建项目
npm build

- 2.启动
node server.js

- 3.访问
localhost:3000
