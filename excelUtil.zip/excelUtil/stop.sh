kill -15 $(lsof -ti :8088)
