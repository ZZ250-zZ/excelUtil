nohup node server.js &
